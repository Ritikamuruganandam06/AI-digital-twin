# backend

Node.js + TypeScript + Express application. Owns MongoDB, Redis, and Kafka
integration, the digital twin's data model, the deterministic simulation
engine, and the internal tool API the AI service calls.

**Phase 5 status:** real Kafka integration via KafkaJS — an idempotent
producer, a consumer group with a dead-letter topic, and explicit topic
creation, all wired into the same health-check registry as MongoDB and
Redis, plus a producer → topic → consumer diagnostic proof mirroring the
Phase 3/4 ones. This sandbox has no way to reach any Kafka broker
distribution (see "What could and couldn't be verified here" below), so
the positive-path proof needs to be run on your own machine.

## Structure (current)

```
backend/
├── src/
│   ├── config/
│   │   ├── env.ts         + redisUrl, redisDefaultTtlSeconds (Phase 4)
│   │   ├── logger.ts
│   │   ├── database.ts    Phase 3
│   │   └── redis.ts       connectToRedis()/disconnectFromRedis()/isRedisConnected()/getRedisClient()
│   ├── cache/
│   │   └── cacheAside.ts  getOrSetCache()/invalidateCache() — generic, reusable cache-aside helper
│   ├── health/
│   │   ├── registry.ts
│   │   └── checks/
│   │       ├── mongodb.check.ts   Phase 3
│   │       ├── redis.check.ts     live SET -> GET -> verify TTL proof, registered in server.ts
│   │       └── kafka.check.ts     Phase 5 — real admin.describeCluster() round trip
│   ├── kafka/
│   │   ├── topics.ts              all topic-name constants for the whole platform (most unused until later phases)
│   │   ├── ensureTopics.ts        explicit admin.createTopics() instead of relying on broker auto-create
│   │   ├── consumerFactory.ts     runConsumer() — generic eachMessage wrapper with dead-letter handling
│   │   ├── producers/diagnosticProducer.ts   Phase 5's own proof-of-Kafka publisher
│   │   └── consumers/
│   │       ├── diagnosticConsumer.ts   subscribes to diagnostics.ping, feeds the in-memory store
│   │       └── store.ts                in-memory ring buffer so consumption is observable over HTTP
│   ├── models/diagnosticPing.model.ts        Mongoose schema (proof-of-CRUD only)
│   ├── repositories/diagnosticPing.repository.ts   pure Mongo data-access, unchanged since Phase 3
│   ├── controllers/diagnosticPing.controller.ts    now cache-aside in front of the repository
│   ├── controllers/diagnosticKafka.controller.ts   Phase 5 — POST publishes, GET reads the consumed-message store
│   ├── routes/diagnosticPing.route.ts        mounted at /api/diagnostics/pings
│   ├── routes/diagnosticKafka.route.ts       mounted at /api/diagnostics/kafka-messages
│   ├── middleware/, routes/health.route.ts, controllers/health.controller.ts,
│   │   utils/AppError.ts, types/express.d.ts   (Phase 2, unchanged)
│   ├── app.ts
│   └── server.ts   now also connects the Kafka producer, ensures topics exist, and starts the
│       diagnostic consumer on boot; disconnects/stops both on shutdown
├── tests/
│   ├── health.test.ts                     Phase 2
│   ├── database.negative.test.ts          Phase 3 — real failed-Mongo-connection proof
│   ├── diagnosticPing.integration.test.ts Phase 3+4 — real CRUD + cache-aside proof (needs Mongo download + real Redis)
│   ├── redis.negative.test.ts             Phase 4 — real failed-Redis-connection proof
│   ├── redis.integration.test.ts          Phase 4 — real SET/GET/TTL + cache-aside proof (needs a real local Redis)
│   └── kafka.negative.test.ts             Phase 5 — real failed-Kafka-connection proof, no broker needed
├── package.json, package-lock.json, tsconfig.json, vitest.config.ts
└── .env.example
```

## Install

```bash
cd backend
npm install
```

## Run

You need MongoDB reachable at `MONGODB_URI`, Redis reachable at
`REDIS_URL`, and a Kafka broker reachable at `KAFKA_BROKERS` (all default
to localhost — install them locally per the root README's prerequisites if
you haven't; Kafka was already a stated Phase 1 prerequisite).

```bash
npm run dev     # tsx watch
# or, if tsx gives you trouble (see the Windows note below):
npm run build && npm start
```

If MongoDB, Redis, or Kafka isn't reachable, the server **still starts** —
`/health` reports each one independently as `"down"`, Redis being down
makes the diagnostic-ping list endpoint fall back to querying MongoDB
directly on every request (slower, not broken) instead of failing, and
Kafka being down makes `POST /api/diagnostics/kafka-messages` return `503`
instead of throwing (the producer/consumer just never started).

**Windows note:** if `npm run dev` fails with `Cannot find module
'./constants'` (or similar) pointing inside `node_modules`, that's a known
`tsx`-on-Windows resolver issue, not a bug here — use
`npm run dev:build-watch` + `npm run dev:run-watch` (two terminals) instead,
or `npm run build && npm start`. Full details in "Common errors" below.

## Verify

```bash
curl -i http://localhost:4000/health
```

With MongoDB, Redis, and Kafka all up, expect:

```json
{"status":"ok","...":"...","checks":{"mongodb":{"status":"ok","latencyMs":1},"redis":{"status":"ok","latencyMs":1},"kafka":{"status":"ok","latencyMs":4}}}
```

Then prove cache-aside end to end — watch `cacheHit` flip:

```bash
curl -s -X POST http://localhost:4000/api/diagnostics/pings \
  -H "Content-Type: application/json" -d '{"message":"cache me"}'

curl -s http://localhost:4000/api/diagnostics/pings   # cacheHit: false (miss, populates Redis)
curl -s http://localhost:4000/api/diagnostics/pings   # cacheHit: true  (hit, served from Redis)

curl -s -X POST http://localhost:4000/api/diagnostics/pings \
  -H "Content-Type: application/json" -d '{"message":"invalidator"}'

curl -s http://localhost:4000/api/diagnostics/pings   # cacheHit: false again — the POST invalidated it
```

You can also inspect the cached value directly: `redis-cli GET
diagnostics:pings:recent:top100` (or `redis-cli TTL ...` to watch the TTL
count down).

Now the Kafka proof — publish a message, then poll for it to land on the
consumer side (this is genuinely asynchronous, so the first `GET` right
after the `POST` may still show it empty for a few hundred milliseconds):

```bash
curl -s -X POST http://localhost:4000/api/diagnostics/kafka-messages \
  -H "Content-Type: application/json" -d '{"message":"hello from kafka"}'
# 202 Accepted: {"data":{"key":"<uuid>","message":"hello from kafka","publishedAt":"..."}}

curl -s http://localhost:4000/api/diagnostics/kafka-messages
# {"data":[{"key":"<same uuid>","message":"hello from kafka","publishedAt":"...","consumedAt":"...","partition":0,"offset":"0"}]}
```

The `key` in the GET response matching the `key` from the POST response,
with a later `consumedAt` than `publishedAt`, is the actual
producer → broker → consumer round trip — not two independent code paths
that happen to agree.

To see the dead-letter path for real, publish a message that the consumer
can't parse by writing directly to the topic with a CLI producer (the
HTTP endpoint always sends valid JSON, by construction, so this needs a
lower-level tool):

```bash
echo "not-json" | kafka-console-producer.sh --broker-list localhost:9092 --topic diagnostics.ping
```

Then check `diagnostics.ping.dlq` for a message whose `error` field says
`Unexpected token ... is not valid JSON` and whose `originalValue` is
`"not-json"`:

```bash
kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic diagnostics.ping.dlq --from-beginning --max-messages 1
```

## Test

```bash
npm test
```

Runs six suites (34 tests total):

- `tests/health.test.ts` (6) — Phase 2, no external services needed.
- `tests/database.negative.test.ts` (4) — real failed-Mongo-connection proof, no MongoDB needed.
- `tests/redis.negative.test.ts` (4) — real failed-Redis-connection proof, no Redis needed.
- `tests/redis.integration.test.ts` (4) — real SET/GET/TTL and cache-aside proof. **Needs a real
  local Redis** reachable at `REDIS_URL` (uses logical DB 15 for isolation — your dev data in
  DB 0 is never touched; see the comment at the top of the file for why there's no
  "redis-memory-server" package involved).
- `tests/kafka.negative.test.ts` (5) — real failed-Kafka-connection proof (connects to
  `127.0.0.1:1`, a port nothing listens on), no broker needed. Verified in this sandbox.
- `tests/diagnosticPing.integration.test.ts` (6) — real Mongo CRUD + real cache-aside proof through
  the actual HTTP endpoint. **Needs both**: a real Redis (same as above) and outbound access to
  `fastdl.mongodb.org` for `mongodb-memory-server`'s one-time binary download. If your network
  blocks that host, this suite fails at `beforeAll` with a `DownloadError` — verify manually with
  the `curl` commands above instead.

There is deliberately no `kafka.integration.test.ts` in this repository yet
— see "What could and couldn't be verified here" below for why, and use
the `curl` sequence above to do that positive-path proof by hand on your
machine.

## Common errors

- `MongoServerSelectionError` / Redis `ECONNREFUSED` on startup — the
  respective service isn't running, or the URI in `.env` is wrong. The
  server still starts; fix the dependency and hit `/health` again.
- `npm run dev` fails with `Cannot find module './constants'` (Windows) —
  known `tsx` resolver issue, unrelated to this codebase. Run
  `npm run build && npm start`, or `npm run dev:build-watch` +
  `npm run dev:run-watch` in two terminals instead. If you want to confirm
  it's this and not a broken install: check that
  `node_modules\mongoose\lib\constants.js` actually exists — if it's
  missing, delete `node_modules` and `package-lock.json` and reinstall;
  if it's there, it's the resolver bug and the workarounds apply.
- `mongodb-memory-server` `DownloadError` when running tests — outbound
  access to `fastdl.mongodb.org` is blocked on your network. Not a bug.
- `EADDRINUSE` — port 4000 already in use; change `PORT` in `.env`.
- `KafkaJSConnectionError` / `KafkaJSNumberOfRetriesExceeded` on startup —
  no broker reachable at `KAFKA_BROKERS`. The server still starts; `/health`
  reports `kafka` as `"down"` and `POST /api/diagnostics/kafka-messages`
  returns `503` instead of a raw error. Start your broker and hit `/health`
  again — nothing needs to be restarted, but this app only tries to connect
  once at boot, so you do need to restart *this* process after the broker
  comes up (Phase 5 doesn't implement a producer reconnect-and-retry loop;
  that's a reasonable thing to revisit if it becomes a real pain point).
- `This server does not host this topic` right after topics are first
  created — a benign, short-lived KafkaJS warning while the new topic's
  metadata propagates across the cluster. It logs, then resolves itself on
  retry; if it doesn't resolve, check `ensureTopics()` actually reached
  your broker.
- Published a message but `GET /api/diagnostics/kafka-messages` never
  shows it — check the server logs for `consumer failed to process
  message` (it will have landed in `diagnostics.ping.dlq` instead), and
  confirm `KAFKA_CONSUMER_GROUP` didn't change between the publish and the
  read (a new group ID starts consuming from the current end of the topic,
  not from messages published before it existed).

## What could and couldn't be verified here

Same situation as MongoDB in Phase 3: this sandbox has no way to run an
actual Kafka broker, and unlike Redis (installable via `apt`), there is no
broker distribution reachable from here at all —

- no `apt` package for a Kafka broker (only client libraries: `librdkafka`,
  `kcat`, various Go clients),
- `archive.apache.org`, `downloads.apache.org`, and `repo.maven.apache.org`
  all return `403` through the sandbox's egress proxy — the same
  organization-policy block that stops `fastdl.mongodb.org` in Phase 3,
  not something route-around-able,
- no Redpanda or other Kafka-API-compatible broker available either.

So what's actually been verified here, versus what needs your machine:

- **Compiles and typechecks clean** (`npx tsc --noEmit`, `npm run build`) —
  verified.
- **Every piece of code that can be exercised without a live broker is
  exercised for real** in `tests/kafka.negative.test.ts`: a genuine
  `connect()` attempt against `127.0.0.1:1` (a port nothing listens on)
  rejecting, the health check correctly reporting `"down"`, `/health`
  returning `503`, and the diagnostic POST endpoint returning a clean `503`
  through `errorHandler` rather than an unhandled exception — verified.
- **The producer → broker → consumer round trip, consumer groups actually
  distributing partitions, and the dead-letter path actually catching a
  malformed message** — this needs a real broker responding to real
  `admin.createTopics()`/`producer.send()`/`consumer.run()` calls, which
  this sandbox cannot provide. This is not verified here. Run the `curl`
  (and `kafka-console-producer.sh`/`kafka-console-consumer.sh`) sequence
  under "Verify" above on your own machine, where Kafka is already a
  stated Phase 1 prerequisite, to complete this proof.

## Design decisions worth knowing

- **The server doesn't crash if MongoDB or Redis is down at boot.** Both
  connection attempts are wrapped in try/catch in `server.ts`; the HTTP
  listener starts regardless, and `/health` reports each dependency's real
  state independently. A Redis outage degrades the app (slower reads,
  `cacheHit` always `false`), it doesn't take it down.
- **`getOrSetCache()` is generic**, not specific to diagnostic pings — it
  takes a key, a TTL, and a `fetcher()` function, so Phase 6's digital-twin
  reads (service topology, metrics) can reuse it directly instead of every
  future phase reinventing cache-aside.
- **A single cache key, not one per `?limit=` value.** The list endpoint
  always caches the 100 most recent pings under one key and slices the
  requested `limit` from that in memory. This makes invalidation trivial —
  one key to delete on every write — at the cost of over-fetching on a
  cache miss. A reasonable trade for a proof-of-cache; a real high-traffic
  endpoint would be tuned differently.
- **`cacheHit` is in the API response, not just in logs.** So cache
  behavior is directly observable (`curl` twice, watch it flip to `true`)
  instead of only provable by reading Redis yourself.
- **The Redis health check does a real SET/GET/TTL round trip**, not just
  `PING` — it writes a random canary value with a TTL on every `/health`
  call, reads it back, and verifies both the value and that the TTL was
  actually applied. This is the project's live "prove Redis actually
  works" check, not just a reachability check.
- **Redis tests use logical DB 15, not a memory-server package.** Unlike
  MongoDB, Redis natively supports 16 isolated logical databases
  (`SELECT 0`–`15`) on a single running instance, so test isolation is a
  `flushdb()` scoped to DB 15 rather than spinning up a separate process.
  Your real dev data (DB 0) is never touched by the test suite.
- **The producer is idempotent (`kafka.producer({ idempotent: true })`).**
  If a `send()` needs to be retried after a network blip, KafkaJS
  de-duplicates it at the broker so the retried message isn't written
  twice — the "idempotency" requirement from the spec, actually enabled,
  not just mentioned in a comment.
- **Every message carries an explicit key** (`producers/diagnosticProducer.ts`).
  Kafka routes all messages sharing a key to the same partition, which is
  what guarantees per-key ordering. This diagnostic producer uses a random
  key per message purely to demonstrate that keyed messages spread across
  `diagnostics.ping`'s 3 partitions; a real producer (Phase 6's
  `service.events`, say) would key by something meaningful like `serviceId`
  so every event for one service stays in order.
- **Topics are created explicitly (`ensureTopics()` / `admin.createTopics()`),
  not left to broker auto-creation.** Most real clusters disable
  auto-creation, and relying on it would hand every topic whatever
  `num.partitions` default the broker happens to have instead of a
  deliberate partition count.
- **One shared consumer group per consumer (`KAFKA_CONSUMER_GROUP`).**
  If you ever run two instances of this backend against the same broker,
  they'll automatically split `diagnostics.ping`'s partitions between them
  instead of each processing every message — that's what a consumer group
  is for. A single instance simply gets all the partitions.
- **`runConsumer()` is generic**, the same pattern as `getOrSetCache()` —
  it takes a `groupId`, a `topic`, an optional `dlqTopic`, and an
  `onMessage` handler, so Phase 6+ consumers (service events, simulation
  events, agent events) reuse the same dead-letter wiring instead of each
  reimplementing try/catch-and-republish.
- **A message that fails processing still gets its offset committed.**
  `consumerFactory.ts` catches the error, logs it, and (if a `dlqTopic` is
  configured) republishes the message there with the error attached — but
  either way, KafkaJS commits the offset once `eachMessage` returns, so one
  permanently-bad message can't stall the whole partition by being retried
  forever. The trade-off: a *transient* failure (a downstream service
  briefly down) also moves on rather than retrying, which is why the
  producer's idempotency and any downstream retry logic matter more than
  consumer-side retries here.
- **KafkaJS's own console-based logger is disabled and routed through
  pino** (`logLevel: logLevel.NOTHING` + a custom `logCreator` in
  `config/kafka.ts`), the same reasoning as everywhere else in this
  codebase: one structured JSON log stream in production, not a second,
  differently-formatted one from a dependency.
